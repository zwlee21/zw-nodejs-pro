package org.jamescarr.amqp.example;


import org.springframework.scheduling.annotation.Scheduled;

public class QueueThreePriceProducer extends RandomPriceProducer {	
	
	@Scheduled(fixedRate=7000)
	public void sendStockOne(){
		Stock sk = produceStock("中石油",12369);
		System.out.println("sending " + sk.getStockName()+" "+sk.getStockNo());		
		getRabbitTemplate().convertAndSend(sk);
	}

}

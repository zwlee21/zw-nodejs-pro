package org.jamescarr.amqp.example;


import org.springframework.scheduling.annotation.Scheduled;

public class QueueFourPriceProducer extends RandomPriceProducer {	
	
	@Scheduled(fixedRate=8000)
	public void sendStockOne(){
		Stock sk = produceStock("南方传媒",12378);
		System.out.println("sending " + sk.getStockName()+" "+sk.getStockNo());		
		getRabbitTemplate().convertAndSend(sk);
	}

}

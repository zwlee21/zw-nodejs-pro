package org.jamescarr.amqp.example;


import org.springframework.scheduling.annotation.Scheduled;

public class QueueTwoPriceProducer extends RandomPriceProducer {	
	
	@Scheduled(fixedRate=6000)
	public void sendStockOne(){
		Stock sk = produceStock("中联通",12368);
		System.out.println("sending " + sk.getStockName()+" "+sk.getStockNo());		
		getRabbitTemplate().convertAndSend(sk);
	}

}

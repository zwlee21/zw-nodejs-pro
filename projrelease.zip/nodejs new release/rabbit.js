var amqp = require('amqp');
var httpd = require('http').createServer(handler);
var io = require('socket.io').listen(httpd);
var fs = require('fs');
   
var connection = amqp.createConnection({ host: "localhost", port: 5672 });
var count = 1;

//web client request handler
function handler(req, res) {
    fs.readFile('index.html',
     function(err, data) {
       if (err) {
         res.writeHead(500);
         return res.end('Error loading index.html');
        }
       res.writeHead(200);
       res.end(data);
      }
   );
  }

//rabbit connection on ready
connection.on('ready', function () {
  connection.exchange("node_exchange", options={type:'fanout'}, function(exchange) {   
   

    var tempData={}; 
   
   
  // Recieve java messages
    connection.queue("my_queue_name_2", function(queue){
      console.log('Created queue')
      queue.bind(exchange, ''); //receive all route key msg

      queue.subscribe(function (message) {
		 console.log('Recieved a message to tempdata');            
                 message.stockNo;
                 tempData[message.stockNo] = message;

           });


    
    //listen to web client
      httpd.listen(6888);
      console.log('listen to 6888')
      io.sockets.on('connection', function (webSocket) {
             console.log('one web client connect,clientId is :' +webSocket.id);
             var  clients = io.sockets.clients(); 
             console.log('current clients numbers :' +clients.length);           
              var tempDataList=[];
              for(stNo in tempData){
               tempDataList.push(tempData[stNo]);
              }
              webSocket.emit('data-update',tempDataList);          
          
           webSocket.on('message', function(msg){

             
           });
           webSocket.on('disconnect', function(){
               console.log('one web client disconnect'); 
               clients = io.sockets.clients();                        
               console.log('current clients numbers :' +clients.length);  
           });
         
           queue.subscribe(function(message){
                 var conns = io.sockets.clients(); 
                 console.log('current clients numbers :' +conns.length);      
                 if(conns.length>0){
                     webSocket.emit('data-update',[message]);  
                     webSocket.broadcast.emit('data-update',[message]); 
                     console.log('Recieved a message and send : '+message.stockNo+'  '+message.stockName); 
                 }
                 message.stockNo;
                 tempData[message.stockNo] = message;
      
              
           })
   
      });
     
    });   
 });
});



 


